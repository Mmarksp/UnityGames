﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hacker : MonoBehaviour
{
    // Game State
    int level;
    enum Screen { MainMenu, Password, Win}; //Finite State Machine
    Screen currentScreen;

    // Start is called before the first frame update
    void Start()
    {
        ShowMainMenu("Mark");
    }

    void ShowMainMenu(string name)
    {
        Terminal.ClearScreen();
        Terminal.WriteLine("Hello "+ name);
        Terminal.WriteLine("They say we all have an opportunity");
        Terminal.WriteLine("A chance to make something of ourselves");
        Terminal.WriteLine("What do you want to hack into first?");
        Terminal.WriteLine("Press 1 for Dad's Cellphone (Easy)");
        Terminal.WriteLine("Press 2 for Mayor's Office (Normal)");
        Terminal.WriteLine("Press 3 for NSA (Hard)");
        Terminal.WriteLine("");
        Terminal.WriteLine("We provide you with a word");
        Terminal.WriteLine("And you will have to finish it");
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnUserInput(string input)
    {
        print("The user typed " + input);
        if (input == "menu")
        {
            currentScreen = Screen.MainMenu;
            ShowMainMenu("Mark");
        }
        if (currentScreen == Screen.MainMenu)
        {
            RunMainMenu(input);
        }
    }

    void RunMainMenu(string input)
    {
        if (input == "1")
        {
            level = 1;
            StartGame();
        }
        else if (input == "2")
        {
            level = 2;
            StartGame();
        }
        else if (input == "3")
        {
            level = 3;
            StartGame();
        }
        else if (input == "destroy")
        {
            Terminal.WriteLine("You have ruined EVERYTHING");
        }
        else
        {
            Terminal.WriteLine("Your input is invalid");
        }
    }

    private void StartGame()
    {
        Terminal.WriteLine("You have chosen level "+ level);
        currentScreen = Screen.Password;
        Terminal.WriteLine("Please enter your password: ");
    }
}
